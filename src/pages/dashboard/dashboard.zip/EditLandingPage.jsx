import LandingDesignEditor, { landingThemeDefaults, landingContentDefaults } from "./LandingDesignEditor";
import React, { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useParams, useNavigate } from "react-router-dom";
import {
  FiArrowLeft,
  FiSave,
  FiImage,
  FiVideo,
  FiTag,
  FiCheckCircle,
  FiPercent,
  FiUploadCloud,
  FiExternalLink,
  FiSliders,
  FiLayers,
} from "react-icons/fi";

import useAxiosSecure from "../../hooks/useAxiosSecure";

const EditLandingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const savedStatusRef = useRef("draft");
  const axiosSecure = useAxiosSecure();
  const axiosRef = useRef(axiosSecure);
  axiosRef.current = axiosSecure;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");
  const [uploadingImage, setUploadingImage] = useState(false);
  const [activeTab, setActiveTab] = useState("content"); // 'content' | 'design'

  const [form, setForm] = useState({
    title: "",
    slug: "",
    status: "draft",
    theme: landingThemeDefaults,
    content: landingContentDefaults,
    gallery: [],
    benefits: [],
    features: [],
    testimonials: [],
    faq: [],
    hero: {
      headline: "",
      subHeadline: "",
      image: "",
    },
    offer: {
      enabled: false,
      oldPrice: "",
      offerPrice: "",
      discountText: "",
    },
    video: {
      enabled: false,
      type: "youtube",
      url: "",
    },
  });

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const loadData = async () => {
      try {
        const res = await axiosRef.current.get(`/api/landing-pages/${id}`);
        const data = res.data.data || res.data;

        if (cancelled) return;
        savedStatusRef.current = data.status || "draft";
        setForm({
          title: data.title || "",
          slug: data.slug || "",
          status: data.status || "draft",
          theme: { ...landingThemeDefaults, ...data.theme },
          content: {
            ...landingContentDefaults,
            ...data.content,
            sectionVisibility: {
              ...landingContentDefaults.sectionVisibility,
              ...data.content?.sectionVisibility,
            },
          },
          gallery: data.gallery || [],
          benefits: data.benefits || [],
          features: data.features || [],
          testimonials: data.testimonials || [],
          faq: data.faq || [],
          hero: {
            headline: data.hero?.headline || "",
            subHeadline: data.hero?.subHeadline || "",
            image: data.hero?.image || "",
          },
          offer: {
            enabled: data.offer?.enabled || false,
            oldPrice: data.offer?.oldPrice || "",
            offerPrice: data.offer?.offerPrice || "",
            discountText: data.offer?.discountText || "",
          },
          video: {
            enabled: data.video?.enabled || false,
            type: data.video?.type || "youtube",
            url: data.video?.url || "",
          },
        });
      } catch (error) {
        if (!cancelled) {
          console.error(error);
          alert("Failed to load landing page");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadData();
    return () => { cancelled = true; };
  }, [id]);

  const updateField = (section, key, value) => {
    setForm((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value,
      },
    }));
  };

  const handleImageUpload = async (e) => {
    const image = e.target.files[0];
    if (!image) return;

    try {
      setUploadingImage(true);
      const body = new FormData();
      body.append("image", image);

      const res = await fetch(
        `https://api.imgbb.com/1/upload?key=${import.meta.env.VITE_IMGBB_API_KEY}`,
        {
          method: "POST",
          body,
        }
      );
      const data = await res.json();
      if (data?.data?.url) {
        updateField("hero", "image", data.data.url);
      }
    } catch (error) {
      console.log(error);
      alert("Image upload failed");
    } finally {
      setUploadingImage(false);
    }
  };

  const savePage = async () => {
    try {
      if (saving) return;
      setSaving(true);
      if (form.status !== savedStatusRef.current) {
        throw new Error("Page Status পরিবর্তনের জন্য আলাদা Publish/Unpublish API ব্যবহার করতে হবে। আগে Status আগের অবস্থায় রাখুন।");
      }

      // Status is managed by a separate backend endpoint.
      const { status, ...payload } = form;
      console.log("VISIBILITY SENT:", payload.content?.sectionVisibility);
      await axiosRef.current.put(`/api/landing-pages/${id}`, payload);

      // Read the persisted page back instead of assuming the update was stored.
      const verifyRes = await axiosRef.current.get(`/api/landing-pages/${id}`);
      const saved = verifyRes.data?.data || verifyRes.data;
      const expectedVisibility = payload.content?.sectionVisibility || {};
      const actualVisibility = saved.content?.sectionVisibility || {};
      const mismatch = Object.keys(expectedVisibility).some(
        (key) => Boolean(expectedVisibility[key]) !== Boolean(actualVisibility[key])
      );
      console.log("VISIBILITY SAVED:", actualVisibility);
      if (mismatch) {
        throw new Error("Section Visibility Database-এ ঠিকভাবে Save হয়নি। Backend Request ও Response পরীক্ষা করুন।");
      }

      await queryClient.invalidateQueries({ queryKey: ["landing-page"] });
      await queryClient.invalidateQueries({ queryKey: ["landing-pages"] });
      setSaveMessage("সফলভাবে Save হয়েছে এবং Database থেকে Visibility যাচাই করা হয়েছে।");
      setForm((prev) => ({
        ...prev,
        content: {
          ...prev.content,
          sectionVisibility: {
            ...landingContentDefaults.sectionVisibility,
            ...actualVisibility,
          },
        },
      }));
    } catch (error) {
      console.log(error);
      setSaveMessage("");
      alert(error.response?.data?.message || error.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  const calculateDiscount = () => {
    const oldP = Number(form.offer.oldPrice);
    const newP = Number(form.offer.offerPrice);
    if (oldP > 0 && newP > 0 && oldP > newP) {
      return Math.round(((oldP - newP) / oldP) * 100);
    }
    return null;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-sm font-medium text-slate-500">
            Landing Page লোড হচ্ছে...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 p-4 md:p-8">
      {/* Sticky Header */}
      <div className="max-w-7xl mx-auto mb-6 bg-white/80 backdrop-blur-md p-4 rounded-2xl border border-slate-200/80 shadow-sm sticky top-4 z-20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition mb-1"
          >
            <FiArrowLeft /> ফিরে যান
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
              Edit Landing Page
            </h1>
            <span
              className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                form.status === "published"
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-amber-100 text-amber-700"
              }`}
            >
              {form.status}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {form.slug && (
            <a
              href={`/lp/${form.slug}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-bold hover:bg-slate-50 transition shadow-sm"
            >
              <FiExternalLink /> View Live
            </a>
          )}
          <button
            onClick={savePage}
            disabled={saving}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-md shadow-indigo-100 transition"
          >
            <FiSave /> {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>

      {saveMessage && (
        <div role="status" className="max-w-7xl mx-auto mb-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
          {saveMessage}
        </div>
      )}

      {/* Main Grid Layout */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Editor Controls & Tabs */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Navigation Tabs */}
          <div className="flex gap-2 p-1.5 bg-slate-200/60 rounded-xl max-w-md">
            <button
              onClick={() => setActiveTab("content")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition ${
                activeTab === "content"
                  ? "bg-white text-indigo-600 shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <FiLayers /> Content & Hero
            </button>
            <button
              onClick={() => setActiveTab("design")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition ${
                activeTab === "design"
                  ? "bg-white text-indigo-600 shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <FiSliders /> Theme & Sections
            </button>
          </div>

          {activeTab === "content" ? (
            <div className="space-y-6">
              {/* Basic Info */}
              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-5">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                  <span className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                    <FiTag className="text-lg" />
                  </span>
                  <div>
                    <h2 className="text-sm font-bold text-slate-800">Basic Information</h2>
                    <p className="text-xs text-slate-400">ল্যান্ডিং পেজের শিরোনাম ও কাস্টম ইউআরএল</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                      Page Title *
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: প্রিমিয়াম লেদার ওয়ালেট"
                      value={form.title}
                      onChange={(e) => setForm({ ...form, title: e.target.value })}
                      className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                      URL Slug *
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3.5 text-xs text-slate-400 font-medium select-none">
                        /lp/
                      </span>
                      <input
                        type="text"
                        placeholder="leather-wallet"
                        value={form.slug}
                        onChange={(e) => setForm({ ...form, slug: e.target.value })}
                        className="w-full pl-12 bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Hero Section */}
              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-5">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                  <span className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
                    <FiImage className="text-lg" />
                  </span>
                  <div>
                    <h2 className="text-sm font-bold text-slate-800">Hero Banner & Content</h2>
                    <p className="text-xs text-slate-400">কাস্টমারকে আকৃষ্ট করার প্রধান ব্যানার ও টেক্সট</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                      Main Headline
                    </label>
                    <input
                      type="text"
                      placeholder="যেমন: আসল চামড়ার তৈরি দীর্ঘস্থায়ী স্টাইলিশ ওয়ালেট"
                      value={form.hero.headline}
                      onChange={(e) => updateField("hero", "headline", e.target.value)}
                      className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                      Sub Headline / Description
                    </label>
                    <textarea
                      rows="4"
                      placeholder="প্রোডাক্ট সম্পর্কে বিস্তারিত বর্ণনা লিখুন..."
                      value={form.hero.subHeadline}
                      onChange={(e) => updateField("hero", "subHeadline", e.target.value)}
                      className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition resize-y"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                      Hero Image
                    </label>

                    <div className="flex flex-col sm:flex-row gap-4 items-start">
                      <div className="flex-1 w-full space-y-2">
                        <input
                          type="text"
                          placeholder="Image URL অথবা নিচে ফাইল আপলোড করুন"
                          value={form.hero.image}
                          onChange={(e) => updateField("hero", "image", e.target.value)}
                          className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                        />
                        <label className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer pt-1">
                          <FiUploadCloud className="text-base" />
                          <span>
                            {uploadingImage ? "আপলোড হচ্ছে..." : "নতুন ইমেজ ফাইল আপলোড করুন"}
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageUpload}
                            disabled={uploadingImage}
                          />
                        </label>
                      </div>

                      {form.hero.image && (
                        <div className="relative group rounded-xl overflow-hidden border border-slate-200 w-24 h-24 shrink-0 bg-slate-100 shadow-inner">
                          <img
                            src={form.hero.image}
                            alt="Hero Preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Special Offer */}
              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-3">
                    <span className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
                      <FiTag className="text-lg" />
                    </span>
                    <div>
                      <h2 className="text-sm font-bold text-slate-800">Special Offer & Pricing</h2>
                      <p className="text-xs text-slate-400">ডিসকাউন্ট এবং অফার প্রাইস কনফিগারেশন</p>
                    </div>
                  </div>

                  {calculateDiscount() && form.offer.enabled && (
                    <span className="flex items-center gap-1 bg-emerald-50 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
                      <FiPercent /> {calculateDiscount()}% Discount
                    </span>
                  )}
                </div>

                <div className="space-y-4">
                  <label className="flex items-center gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={form.offer.enabled}
                      onChange={(e) => updateField("offer", "enabled", e.target.checked)}
                      className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-slate-300"
                    />
                    <span className="text-sm font-semibold text-slate-800">
                      Enable Special Offer Pricing
                    </span>
                  </label>

                  {form.offer.enabled && (
                    <div className="space-y-4 pt-2">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                            Old Price (৳)
                          </label>
                          <input
                            type="number"
                            placeholder="1200"
                            value={form.offer.oldPrice}
                            onChange={(e) => updateField("offer", "oldPrice", e.target.value)}
                            className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                            Offer Price (৳)
                          </label>
                          <input
                            type="number"
                            placeholder="850"
                            value={form.offer.offerPrice}
                            onChange={(e) => updateField("offer", "offerPrice", e.target.value)}
                            className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                          Custom Discount Text
                        </label>
                        <input
                          type="text"
                          placeholder="যেমন: ৩০% ছাড় অথবা সীমিত সময়ের অফার"
                          value={form.offer.discountText}
                          onChange={(e) => updateField("offer", "discountText", e.target.value)}
                          className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Video Showcase */}
              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-5">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                  <span className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
                    <FiVideo className="text-lg" />
                  </span>
                  <div>
                    <h2 className="text-sm font-bold text-slate-800">Product Video Showcase</h2>
                    <p className="text-xs text-slate-400">ইউটিউব বা ভিডিও এম্বেড শোকেস</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="flex items-center gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={form.video.enabled}
                      onChange={(e) => updateField("video", "enabled", e.target.checked)}
                      className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-slate-300"
                    />
                    <span className="text-sm font-semibold text-slate-800">
                      Show Video on Landing Page
                    </span>
                  </label>

                  {form.video.enabled && (
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                        YouTube Embed URL
                      </label>
                      <input
                        type="text"
                        placeholder="https://www.youtube.com/embed/xxxxxx"
                        value={form.video.url}
                        onChange={(e) => updateField("video", "url", e.target.value)}
                        className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-sm rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <LandingDesignEditor value={form} onChange={setForm} />
          )}
        </div>

        {/* Right Column: Visibility & Actions */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 space-y-5 sticky top-28">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <span className="p-2.5 bg-slate-100 text-slate-700 rounded-xl">
                <FiCheckCircle className="text-lg" />
              </span>
              <div>
                <h2 className="text-sm font-bold text-slate-800">Publish Settings</h2>
                <p className="text-xs text-slate-400">স্ট্যাটাস ও সেভ অপশন</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-2">
                Page Status
              </label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="w-full bg-slate-50/60 border border-slate-200 text-slate-800 text-xs font-bold rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 p-3 outline-none transition"
              >
                <option value="draft">📁 Draft (লুকানো থাকবে)</option>
                <option value="published">🚀 Published (লাইভ থাকবে)</option>
              </select>
            </div>

            <hr className="border-slate-100" />

            <div className="space-y-2.5">
              <button
                onClick={savePage}
                disabled={saving}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white p-3 rounded-xl text-xs font-bold shadow-md shadow-indigo-100 transition"
              >
                <FiSave className="text-sm" />
                {saving ? "Saving Changes..." : "Save Changes"}
              </button>

              <button
                type="button"
                onClick={() => navigate(-1)}
                className="w-full p-3 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50 transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default EditLandingPage;